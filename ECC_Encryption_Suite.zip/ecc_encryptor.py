
from tinyec import registry
from secrets import randbelow
import time, sys
from tqdm import tqdm

def typewriter(text, delay=0.02):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def separator():
    print("=" * 60)

# توليد المفتاح العام والخاص
typewriter(">>> Launching ECC Ultra Key Generator...")
separator()
curve = registry.get_curve('secp192r1')
privKey = randbelow(curve.field.n)
pubKey = privKey * curve.g

# رسالة سرية
message = 1337
k = randbelow(curve.field.n)
C1 = k * curve.g
shared = k * pubKey
C2 = message + shared.x

typewriter(">>> Encrypting Top-Secret Payload...")
for _ in tqdm(range(100), desc="Encryption Progress"):
    time.sleep(0.01)

# حفظ البيانات
with open("ecc_data.txt", "w") as f:
    f.write(f"{privKey}\n{C1.x},{C1.y}\n{C2}")

separator()
typewriter(">>> ENCRYPTION COMPLETE!")
typewriter(f"Private Key  : {privKey}")
typewriter(f"Public Point : ({pubKey.x}, {pubKey.y})")
typewriter(f"Encrypted C1 : ({C1.x}, {C1.y})")
typewriter(f"Encrypted C2 : {C2}")
separator()
typewriter(">>> Data saved to ecc_data.txt")
