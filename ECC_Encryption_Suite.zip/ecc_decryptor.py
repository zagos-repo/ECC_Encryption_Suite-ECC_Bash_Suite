
from tinyec import registry
import time, sys
from tqdm import tqdm

def typewriter(text, delay=0.02):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def separator():
    print("=" * 60)

# تحميل البيانات
typewriter(">>> ECC Decryption System Initialized...")
separator()
with open("ecc_data.txt", "r") as f:
    lines = f.read().splitlines()
    privKey = int(lines[0])
    x, y = map(int, lines[1].split(','))
    C2 = int(lines[2])

curve = registry.get_curve('secp192r1')
C1 = curve.point_class(x, y, curve)

typewriter(">>> Synchronizing with ECC Space Network...")
for _ in tqdm(range(100), desc="Satellite Sync"):
    time.sleep(0.01)

# فك التشفير
shared = privKey * C1
original = C2 - shared.x

separator()
typewriter(">>> DECRYPTION SUCCESSFUL!")
typewriter(f"Decrypted Message: {original}")
separator()
